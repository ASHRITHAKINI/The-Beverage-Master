package com.example.aion_cocktail_machine

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
