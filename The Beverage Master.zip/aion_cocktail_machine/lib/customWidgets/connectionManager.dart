import 'dart:io';
import 'package:flutter/foundation.dart';
import 'package:wifi_iot/wifi_iot.dart' show NetworkSecurity, WiFiForIoTPlugin;

class ConnectionManager extends ChangeNotifier {
  bool _isConnected = false;
  Socket? _socket;

  bool get isConnected => _isConnected;
  Socket? get socket => _socket;

  Future<void> connect() async {
    if (!_isConnected) {
      try {
        bool connected = await WiFiForIoTPlugin.connect(
          "Cocktail Machine",
          password: "12345678",
          security: NetworkSecurity.WPA,
          joinOnce: true,
          withInternet: false,
        );
        if (connected) {
          _socket = await Socket.connect('192.168.0.1', 8080);
          _isConnected = true;
          notifyListeners();
        } else {
          print('Failed to connect to Cocktail Machine');
        }
      } catch (e) {
        print('Error connecting to WiFi: $e');
      }
    }
  }

  void disconnect() {
    if (_isConnected) {
      _socket?.close();
      _isConnected = false;
      notifyListeners();
    }
  }

  Future<void> sendCommand(String command) async {
    if (_isConnected && _socket != null) {
      _socket!.write(command);
    } else {
      print('Not connected to the socket');
    }
  }

  @override
  void dispose() {
    disconnect();
    super.dispose();
  }
}
