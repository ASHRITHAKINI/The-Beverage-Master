import 'package:flutter/material.dart';
import 'package:flip_card/flip_card.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:wifi_iot/wifi_iot.dart';
import '../menu/drinks.dart';
import 'SocketManager.dart';

// Helper function to get contrasting text color
Color getContrastingTextColor(Color backgroundColor) {
  double luminance = (0.299 * backgroundColor.red +
      0.587 * backgroundColor.green +
      0.114 * backgroundColor.blue) /
      255;
  return luminance > 0.5 ? Colors.black : Colors.white;
}

class CustomizeDrinkTile extends StatefulWidget {
  final Drinks drink;
  final void Function()? onTap;

  const CustomizeDrinkTile({
    Key? key,
    required this.drink,
    this.onTap,
  }) : super(key: key);

  @override
  _CustomizeDrinkTileState createState() => _CustomizeDrinkTileState();
}

class _CustomizeDrinkTileState extends State<CustomizeDrinkTile> {
  bool _isDispensing = false;
  final SocketManager _socketManager = SocketManager();

  Future<void> _checkWiFiAndSendCommand(BuildContext context, String command) async {
    var connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.wifi) {
      await _sendCommand(context, command);
    } else {
      bool connected = await _connectToWiFi(context);
      if (connected) {
        await _sendCommand(context, command);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to connect to WiFi')),
        );
      }
    }
  }

  Future<bool> _connectToWiFi(BuildContext context) async {
    try {
      bool isConnected = await WiFiForIoTPlugin.connect(
        "Cocktail Machine",
        password: "12345678",
        security: NetworkSecurity.WPA,
        joinOnce: true,
        withInternet: false,
      );
      if (isConnected) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Cocktail Machine connected'),
            duration: Duration(seconds: 2),
          ),
        );
        return true;
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to connect to Cocktail Machine'),
            duration: Duration(seconds: 2),
          ),
        );
        return false;
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error connecting to WiFi: $e'),
          duration: Duration(seconds: 2),
        ),
      );
      return false;
    }
  }

  Future<void> _sendCommand(BuildContext context, String command) async {
    try {
      await _socketManager.sendCommand(command);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final tileWidth = screenWidth * 0.93;
    final backgroundColor = Theme.of(context).colorScheme.background;
    final textColor = getContrastingTextColor(backgroundColor);

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: SizedBox(
            width: tileWidth,
            child: GestureDetector(
              onTap: widget.onTap,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: FlipCard(
                  direction: FlipDirection.HORIZONTAL,
                  front: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      color: backgroundColor,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black26,
                          blurRadius: 10,
                          offset: Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      '${widget.drink.name}',
                                      style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                        color: textColor,
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    ElevatedButton(
                                      onPressed: _isDispensing
                                          ? () async {
                                        await stopDispensing(context);
                                      }
                                          : () async {
                                        await _showPreparePopup(context);
                                      },
                                      child: Text(
                                        _isDispensing ? "Stop Dispensing" : "Prepare",
                                        style: const TextStyle(fontSize: 12),
                                      ),
                                    ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 8),
                              Container(
                                width: 80,
                                height: 80,
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(16),
                                  child: Image.asset(
                                    widget.drink.imagePath,
                                    fit: BoxFit.cover,
                                    errorBuilder: (context, error, stackTrace) {
                                      return const Icon(Icons.error);
                                    },
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  back: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      color: backgroundColor,
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black26,
                          blurRadius: 10,
                          offset: Offset(0, 4),
                        ),
                      ],
                    ),
                    alignment: Alignment.center,
                    child: Padding(
                      padding: const EdgeInsets.all(16.0),
                      child: Text(
                        widget.drink.description,
                        style: TextStyle(
                          fontSize: 16,
                          color: textColor,
                        ),
                        textAlign: TextAlign.center,
                      ),
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }

  Future<void> sendPrepareMessage(BuildContext context) async {
    setState(() {
      _isDispensing = true;
    });

    String command = '60\n'; // Adjust command based on your specific needs

    await _checkWiFiAndSendCommand(context, command);

    // Optionally, you can show a popup after sending the prepare command
    // await _showStopPopup(context);
  }

  Future<void> stopDispensing(BuildContext context) async {
    String stopCommand = '61\n'; // Adjust stop command based on your specific needs

    await _checkWiFiAndSendCommand(context, stopCommand);

    setState(() {
      _isDispensing = false;
    });
  }

  Future<void> _showPreparePopup(BuildContext context) async {
    await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(
            'Prepare Drink',
            style: TextStyle(color: Theme.of(context).colorScheme.primary),
          ),
          content: Text(
            'Do you want to prepare ${widget.drink.name}?',
            style: TextStyle(color: Theme.of(context).colorScheme.primary),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.pop(context);
              },
              child: Text('Cancel'),
            ),
            TextButton(
              onPressed: () async {
                Navigator.pop(context);
                await sendPrepareMessage(context);
              },
              child: Text('Yes'),
            ),
          ],
        );
      },
    );
  }

  @override
  void dispose() {
    _socketManager.dispose(); // Dispose socket manager
    super.dispose();
  }
}
