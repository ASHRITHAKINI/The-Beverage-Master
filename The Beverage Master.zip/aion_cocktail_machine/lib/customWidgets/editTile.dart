import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../menu/item.dart';
import '../menu/drinks.dart';

class EditTilePage extends StatefulWidget {
  final Drinks drink;
  final void Function(Drinks updatedDrink)? onUpdate;

  EditTilePage({Key? key, required this.drink, this.onUpdate}) : super(key: key);

  @override
  _EditTilePageState createState() => _EditTilePageState();
}

class _EditTilePageState extends State<EditTilePage> {
  late TextEditingController _nameController;
  late TextEditingController _imageController;
  late TextEditingController _descriptionController;
  List<TextEditingController> _addonControllers = [];
  File? _imageFile;

  @override
  void initState() {
    super.initState();
    _nameController = TextEditingController(text: widget.drink.name);
    _imageController = TextEditingController(text: widget.drink.imagePath ?? '');
    _descriptionController = TextEditingController(text: widget.drink.description);

    _addonControllers = widget.drink.availableAddons
        .map((addon) => TextEditingController(text: addon.quantity.toString()))
        .toList();
  }

  @override
  void dispose() {
    _nameController.dispose();
    _imageController.dispose();
    _descriptionController.dispose();
    _addonControllers.forEach((controller) => controller.dispose());
    super.dispose();
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final pickedFile = await picker.pickImage(source: ImageSource.gallery);
    if (pickedFile != null) {
      setState(() {
        _imageFile = File(pickedFile.path);
        _imageController.text = pickedFile.path;
      });
    }
  }

  void _updateTile() {
    final updatedAddons = List<Addon>.generate(
      _addonControllers.length,
          (index) => Addon(
        name: widget.drink.availableAddons[index].name,
        quantity: int.tryParse(_addonControllers[index].text) ?? 0,
        maxVolume: 200,
      ),
    );

    Drinks updatedDrink = Drinks(
      name: _nameController.text,
      description: _descriptionController.text,
      imagePath: _imageController.text,
      category: widget.drink.category,
      availableAddons: updatedAddons,
      tileNumber: widget.drink.tileNumber,
    );

    Provider.of<Item>(context, listen: false).updateDrink(updatedDrink);

    if (widget.onUpdate != null) {
      widget.onUpdate!(updatedDrink);
    }

    Navigator.of(context).pop();
  }

  Widget _buildTextField({
    required String labelText,
    required TextEditingController controller,
    required String hintText,
    TextInputType keyboardType = TextInputType.text,
    String? Function(String?)? validator,
    Function(String)? onChanged,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 16.0),
      decoration: BoxDecoration(
        border: Border.all(
          color: Theme.of(context).colorScheme.inversePrimary,
        ),
        borderRadius: BorderRadius.circular(10.0),
      ),
      child: Padding(
        padding: EdgeInsets.all(8.0),
        child: TextFormField(
          controller: controller,
          decoration: InputDecoration(
            labelText: labelText,
            hintText: hintText,
            labelStyle: TextStyle(color: Theme.of(context).colorScheme.inversePrimary),
            hintStyle: TextStyle(color: Theme.of(context).colorScheme.inversePrimary),
          ),
          style: TextStyle(color: Theme.of(context).colorScheme.inversePrimary),
          keyboardType: keyboardType,
          validator: validator,
          onChanged: onChanged,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final item = Provider.of<Item>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Edit Tile'),
      ),
      body: Padding(
        padding: const EdgeInsets.all(16.0),
        child: Container(
          decoration: BoxDecoration(
            border: Border.all(
              color: Theme.of(context).colorScheme.inversePrimary,
            ),
            borderRadius: BorderRadius.circular(10.0),
          ),
          padding: EdgeInsets.all(16.0),
          child: ListView(
            children: [
              _buildTextField(
                labelText: 'Drink Name',
                controller: _nameController,
                hintText: 'Enter drink name',
              ),
              _buildTextField(
                labelText: 'Description',
                controller: _descriptionController,
                hintText: 'Enter description',
              ),
              Row(
                children: [
                  Expanded(
                    child: _buildTextField(
                      labelText: 'Image Path',
                      controller: _imageController,
                      hintText: 'Enter image path or choose',
                    ),
                  ),
                  IconButton(
                    icon: Icon(Icons.image),
                    color: Theme.of(context).colorScheme.inversePrimary,
                    onPressed: _pickImage,
                  ),
                ],
              ),
              if (widget.drink.category != drinkCategory.ManualDispenser) ...[
                SizedBox(height: 16),
                Text(
                  'Ingredients (in ml)',
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.inversePrimary,
                    fontSize: 16.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 8.0),
                ...List.generate(
                  item.manualDispenserAddons.length,
                      (index) => _buildTextField(
                    labelText: item.manualDispenserAddons[index].name,
                    controller: _addonControllers[index],
                    hintText: 'Volume (in ml)',
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a quantity';
                      }
                      final quantity = int.tryParse(value);
                      if (quantity == null || quantity < 0 || quantity > 200) {
                        return 'Quantity must be between 0 and 200 ml';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      setState(() {
                        _addonControllers[index].text = value;
                      });
                    },
                  ),
                ),
              ],
              SizedBox(height: 16),
              ElevatedButton(
                onPressed: _updateTile,
                child: Text(
                  'Update Tile',
                  style: TextStyle(color: Colors.green),
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }
}
