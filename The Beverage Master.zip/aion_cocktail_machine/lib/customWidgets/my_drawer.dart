import 'package:flutter/material.dart';

import '../pages/settings_page.dart';
import 'my_drawer_tile.dart';

class MyDrawer extends StatelessWidget {
  final VoidCallback onReset;

  const MyDrawer({super.key, required this.onReset});

  @override
  Widget build(BuildContext context) {
    return Drawer(
      backgroundColor: Theme.of(context).colorScheme.background,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.only(top: 100.0),
            child: Image.asset(
              'lib/images/logo/logo.png',
              width: 150,
              height: 160,
              fit: BoxFit.cover,
            ),
          ),

          Padding(
            padding: const EdgeInsets.all(25.0),
            child: Divider(
              color: Theme.of(context).colorScheme.inversePrimary,
            ),
          ),

          MyDrawerTile(
              text: "H O M E",
              icon: Icons.home,
              onTap: () => {
                Navigator.pop(context),
              }
          ),

          MyDrawerTile(
            text: "S E T T I N G S",
            icon: Icons.settings,
            onTap: (){
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const SettingsPage(),
                ),
              );
            },
          ),

          /*MyDrawerTile(
              text: "E D I T  T I L E",
              icon: Icons.home,
            onTap: (){
              Navigator.pop(context);
              Navigator.push(
                context,
                MaterialPageRoute(
                  builder: (context) => const SettingsPage(),
                ),
              );
            },
          ),*/

          const Spacer(),

          /*Padding(
            padding: const EdgeInsets.all(5.0),
            child: Divider(
              color: Theme.of(context).colorScheme.inversePrimary,
            ),
          ),*/

          /*MyDrawerTile(
            text: "RESET",
            icon: Icons.refresh,
            onTap: onReset,
          ),*/

          /*const SizedBox(height: 25),*/
        ],
      ),
    );
  }
}
