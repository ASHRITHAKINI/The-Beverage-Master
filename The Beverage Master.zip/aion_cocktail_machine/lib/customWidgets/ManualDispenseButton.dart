import 'package:flutter/material.dart';
import 'package:connectivity_plus/connectivity_plus.dart';
import 'package:wifi_iot/wifi_iot.dart';
import 'SocketManager.dart';
import 'dart:io';

class ManualDispenseButton extends StatefulWidget {
  final int tileNumber;
  final bool isDispensing;
  final void Function(bool isDispensing) onDispenseStatusChanged;
  final String imagePath;

  const ManualDispenseButton({
    Key? key,
    required this.tileNumber,
    required this.isDispensing,
    required this.onDispenseStatusChanged,
    required this.imagePath,
  }) : super(key: key);

  @override
  _ManualDispenseButtonState createState() => _ManualDispenseButtonState();
}

class _ManualDispenseButtonState extends State<ManualDispenseButton> {
  final SocketManager _socketManager = SocketManager();

  Future<void> _checkWiFiAndSendCommand(BuildContext context, String command) async {
    var connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.wifi) {
      await _sendCommand(context, command);
    } else {
      bool connected = await _connectToWiFi(context);
      if (connected) {
        await _sendCommand(context, command);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to connect to WiFi')),
        );
      }
    }
  }

  Future<bool> _connectToWiFi(BuildContext context) async {
    try {
      bool isConnected = await WiFiForIoTPlugin.connect(
        "Cocktail Machine",
        password: "12345678",
        security: NetworkSecurity.WPA,
        joinOnce: true,
        withInternet: false,
      );
      if (isConnected) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Cocktail Machine connected'),
            duration: Duration(seconds: 2),
          ),
        );
        return true;
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to connect to Cocktail Machine'),
            duration: Duration(seconds: 2),
          ),
        );
        return false;
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error connecting to WiFi: $e'),
          duration: Duration(seconds: 2),
        ),
      );
      return false;
    }
  }

  Future<void> _sendCommand(BuildContext context, String command) async {
    try {
      await _socketManager.sendDispenseCommand(command);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  Future<void> sendDispenseCommand(BuildContext context) async {
    String command;
    switch (widget.tileNumber) {
      case 1:
        command = '60\n';
        break;
      case 2:
        command = '62\n';
        break;
      case 3:
        command = '64\n';
        break;
      case 4:
        command = '66\n';
        break;
      case 5:
        command = '68\n';
        break;
      case 6:
        command = '70\n';
        break;
      default:
        command = '60\n'; // Default command
        break;
    }

    await _checkWiFiAndSendCommand(context, command);

    widget.onDispenseStatusChanged(true);
    _showDispensePopup(context); // Show the popup
  }

  Future<void> stopDispensing(BuildContext context) async {
    String stopCommand;
    switch (widget.tileNumber) {
      case 1:
        stopCommand = '61\n';
        break;
      case 2:
        stopCommand = '63\n';
        break;
      case 3:
        stopCommand = '65\n';
        break;
      case 4:
        stopCommand = '67\n';
        break;
      case 5:
        stopCommand = '69\n';
        break;
      case 6:
        stopCommand = '71\n';
        break;
      default:
        stopCommand = '61\n'; // Default stop command
        break;
    }

    await _checkWiFiAndSendCommand(context, stopCommand);

    widget.onDispenseStatusChanged(false);
    Navigator.of(context).pop(); // Close the popup
  }

  Future<void> _showDispensePopup(BuildContext context) async {
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        return AlertDialog(
          title: Text(
            'Dispensing Drink',
            style: TextStyle(color: Theme.of(context).colorScheme.primary),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  widget.imagePath.isNotEmpty
                      ? Image.file(
                    File(widget.imagePath),
                    height: 100,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return const Icon(Icons.error);
                    },
                  )
                      : Image.asset(
                    'lib/images/default.jpg',
                    height: 100,
                    fit: BoxFit.cover,
                    errorBuilder: (context, error, stackTrace) {
                      return const Icon(Icons.error);
                    },
                  ),
                  CircularProgressIndicator(),
                ],
              ),
              SizedBox(height: 20),
              Text(
                'Your drink is being dispensed...',
                style: TextStyle(color: Theme.of(context).colorScheme.primary),
              ),
            ],
          ),
          actions: [
            OutlinedButton(
              style: OutlinedButton.styleFrom(
                side: BorderSide(color: Colors.white, width: 1), // Add white border
              ),
              onPressed: () async {
                await stopDispensing(context);
              },
              child: Text('Stop Dispensing'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    return ElevatedButton(
      style: ElevatedButton.styleFrom(
        backgroundColor: Theme.of(context).colorScheme.secondary, // Set button color
        shape: RoundedRectangleBorder(
          borderRadius: BorderRadius.circular(10),
        ),
        padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
        side: BorderSide(color: Colors.white, width: 1), // Add white border
      ),
      onPressed: widget.isDispensing
          ? () async {
        await stopDispensing(context);
      }
          : () async {
        await sendDispenseCommand(context);
      },
      child: Text(widget.isDispensing ? "Stop Dispensing" : "Dispense"),
    );
  }
}
