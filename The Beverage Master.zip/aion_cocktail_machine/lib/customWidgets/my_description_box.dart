import 'package:flutter/material.dart';
import 'package:connectivity/connectivity.dart';
import 'dart:async'; // Import dart:async for StreamSubscription

class MyDescriptionBox extends StatefulWidget {
  const MyDescriptionBox({Key? key, required String description}) : super(key: key);

  @override
  _MyDescriptionBoxState createState() => _MyDescriptionBoxState();
}

class _MyDescriptionBoxState extends State<MyDescriptionBox> {
  bool isConnected = false;
  late Connectivity _connectivity;
  late StreamSubscription<ConnectivityResult> _connectivitySubscription;

  @override
  void initState() {
    super.initState();
    _connectivity = Connectivity();
    _connectivitySubscription = _connectivity.onConnectivityChanged.listen((ConnectivityResult result) {
      if (result == ConnectivityResult.wifi) {
        setState(() {
          isConnected = true;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Cocktail Machine connected'),
            duration: Duration(seconds: 2),
          ),
        );
      } else {
        setState(() {
          isConnected = false;
        });
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Disconnected from Cocktail Machine'),
            duration: Duration(seconds: 2),
          ),
        );
      }
    });
    _checkInitialConnection();
  }

  @override
  void dispose() {
    _connectivitySubscription.cancel();
    super.dispose();
  }

  void _checkInitialConnection() async {
    ConnectivityResult result = await _connectivity.checkConnectivity();
    if (result == ConnectivityResult.wifi) {
      setState(() {
        isConnected = true;
      });
    } else {
      setState(() {
        isConnected = false;
      });
    }
  }

  @override
  Widget build(BuildContext context) {
    Color statusColor = isConnected ? Colors.green : Colors.red;
    String statusText = isConnected ? "Connected" : "Disconnected";
    IconData icon = isConnected ? Icons.wifi : Icons.wifi_off;

    return Padding(
      padding: const EdgeInsets.all(10.0),
      child: Container(
        padding: const EdgeInsets.all(10.0),
        decoration: BoxDecoration(
          color: Theme.of(context).colorScheme.background,
          border: Border.all(color: Theme.of(context).colorScheme.inversePrimary),
          borderRadius: BorderRadius.circular(10.0),
        ),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text(
                  "WiFi status: ",
                  style: TextStyle(
                    fontSize: 16,
                    fontWeight: FontWeight.bold,
                    color: Theme.of(context).colorScheme.inversePrimary,
                  ),
                ),
                Text(
                  statusText,
                  style: TextStyle(
                    color: statusColor,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(width: 5),
                Icon(
                  icon,
                  color: statusColor,
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
