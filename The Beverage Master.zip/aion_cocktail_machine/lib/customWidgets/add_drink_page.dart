import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../customWidgets/customizeDrinkPage.dart';
import '../customWidgets/my_description_box.dart';
import '../customWidgets/my_drawer.dart';
import '../customWidgets/my_drink_tile.dart';
import '../customWidgets/my_silver_app_bar.dart';
import '../customWidgets/my_tab_bar.dart';
import '../menu/drinks.dart';
import '../menu/item.dart';
import '../pages/drink_page.dart';
import '../themes/themeProvider.dart';
import 'package:wifi_iot/wifi_iot.dart' show WiFiForIoTPlugin;

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  late List<Drinks> _drinks;
  int _highestTileNumber = 0;
  bool _isConnectedToWiFi = false;

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: drinkCategory.values.length,
      vsync: this,
      initialIndex: drinkCategory.ManualDispenser.index,
    );
    // _drinks = Provider.of<Item>(context, listen: false).menu;
    _highestTileNumber = _getHighestTileNumber();
    _checkWiFiStatus();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  int _getHighestTileNumber() {
    int highestNumber = 0;
    for (var drink in _drinks) {
      if (drink.tileNumber != null && drink.tileNumber! > highestNumber) {
        highestNumber = drink.tileNumber!;
      }
    }
    return highestNumber;
  }

  void _addDrink(Drinks drink) {
    setState(() {
      _drinks.add(drink);
      _highestTileNumber = drink.tileNumber!;
    });
  }

  List<Drinks> _filterMenuByCategory(drinkCategory category, List<Drinks> fullMenu) {
    return fullMenu.where((drink) => drink.category == category).toList();
  }

  List<Widget> getDrinkTilesInThisCategory(List<Drinks> fullMenu) {
    return drinkCategory.values.map((category) {
      List<Drinks> categoryMenu = _filterMenuByCategory(category, fullMenu);
      return categoryMenu.isEmpty
          ? Center(
        child: ElevatedButton(
          onPressed: () {
            Drinks newDrink = Drinks(
              name: 'New Drink',
              description: 'New Drink Description',
              imagePath: 'assets/default_image.png',
              category: category,
              availableAddons: [],
              tileNumber: _highestTileNumber + 1,
            );

            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => CustomizeDrinkPage(drink: newDrink, onDrinkSaved: (Drinks ) {  },),
              ),
            );
          },
          child: Text('Add Drink Tile'),
        ),
      )
          : ListView.builder(
        itemCount: categoryMenu.length,
        physics: const NeverScrollableScrollPhysics(),
        padding: EdgeInsets.zero,
        itemBuilder: (context, index) {
          final drink = categoryMenu[index];
          return DrinkTile(
            drink: drink,
            onTap: () => Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => DrinkPage(drink: drink),
              ),
            ),
            tileNumber: drink.tileNumber!, // Ensure tileNumber is not null
          );
        },
      );
    }).toList();
  }

  void _checkWiFiStatus() async {
    // Replace with your WiFi checking logic
    bool isConnected = await WiFiForIoTPlugin.isConnected();
    setState(() {
      _isConnectedToWiFi = isConnected;
    });
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final isDarkMode = themeProvider.isDarkMode;

    return Scaffold(
      drawer: MyDrawer(onReset: () {  }),
      backgroundColor: Theme.of(context).colorScheme.secondary,
      body: SafeArea(
        child: NestedScrollView(
          headerSliverBuilder: (context, innerBoxIsScrolled) => [
            MySliverAppBar(
              child: MyDescriptionBox(description: '',), // Add MyDescriptionBox widget here
              title: MyTabBar(
                tabController: _tabController,
              ), tabController: _tabController,
            ),
          ],
          body: TabBarView(
            controller: _tabController,
            children: drinkCategory.values.map((category) {
              List<Drinks> categoryMenu = _filterMenuByCategory(category, _drinks);
              return category == drinkCategory.ManualDispenser
                  ? ListView.builder(
                itemCount: categoryMenu.length,
                physics: const NeverScrollableScrollPhysics(),
                padding: EdgeInsets.zero,
                itemBuilder: (context, index) {
                  final drink = categoryMenu[index];
                  return DrinkTile(
                    drink: drink,
                    onTap: () => Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => DrinkPage(drink: drink),
                      ),
                    ),
                    tileNumber: drink.tileNumber!, // Ensure tileNumber is not null
                  );
                },
              )
                  : Center(
                child: ElevatedButton(
                  onPressed: () {
                    Drinks newDrink = Drinks(
                      name: 'New Drink',
                      description: 'New Drink Description',
                      imagePath: 'assets/default_image.png',
                      category: category,
                      availableAddons: [],
                      tileNumber: _highestTileNumber + 1,
                    );

                    Navigator.push(
                      context,
                      MaterialPageRoute(
                        builder: (context) => CustomizeDrinkPage(drink: newDrink, onDrinkSaved: (Drinks ) {  },),
                      ),
                    );
                  },
                  child: Text('Add Drink Tile'),
                ),
              );
            }).toList(),
          ),
        ),
      ),
    );
  }
}
