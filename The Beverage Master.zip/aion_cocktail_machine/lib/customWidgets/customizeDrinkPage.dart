import 'dart:io';
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../menu/item.dart';
import '../menu/drinks.dart';

class CustomizeDrinkPage extends StatefulWidget {
  final Drinks drink;
  final Function(Drinks) onDrinkSaved;

  CustomizeDrinkPage({required this.drink, required this.onDrinkSaved});

  @override
  _CustomizeDrinkPageState createState() => _CustomizeDrinkPageState();
}

class _CustomizeDrinkPageState extends State<CustomizeDrinkPage> {
  final _formKey = GlobalKey<FormState>();
  TextEditingController _nameController = TextEditingController();
  TextEditingController _descriptionController = TextEditingController();
  TextEditingController _imageController = TextEditingController();
  List<TextEditingController> _addonControllers = [];
  List<int> _addonQuantities = [];
  bool _nameFieldHasFocus = false;
  bool _descriptionFieldHasFocus = false;
  File? _imageFile;

  @override
  void initState() {
    super.initState();
    final item = Provider.of<Item>(context, listen: false);
    _addonControllers = List.generate(item.manualDispenserAddons.length, (index) => TextEditingController());
    _addonQuantities = List.generate(item.manualDispenserAddons.length, (index) => 0);
    if (widget.drink.imagePath != null) {
      _imageController.text = widget.drink.imagePath!;
    }
  }

  @override
  void dispose() {
    _nameController.dispose();
    _descriptionController.dispose();
    _imageController.dispose();
    for (var controller in _addonControllers) {
      controller.dispose();
    }
    super.dispose();
  }

  void _saveDrink() {
    if (_formKey.currentState!.validate()) {
      final updatedAddons = List<Addon>.generate(
        _addonControllers.length,
            (index) => Addon(
          name: Provider.of<Item>(context, listen: false).manualDispenserAddons[index].name,
          quantity: _addonQuantities[index],
          maxVolume: 200,
        ),
      );

      final updatedDrink = Drinks(
        name: _nameController.text,
        description: _descriptionController.text,
        imagePath: _imageController.text,
        category: widget.drink.category,
        availableAddons: updatedAddons,
        tileNumber: widget.drink.tileNumber,
      );

      widget.onDrinkSaved(updatedDrink);
      Navigator.pop(context);
    }
  }

  Future<void> _pickImage(ImageSource source) async {
    final pickedFile = await ImagePicker().pickImage(source: source);
    if (pickedFile != null) {
      setState(() {
        _imageFile = File(pickedFile.path);
        _imageController.text = pickedFile.path;
      });
    }
  }

  Widget _buildTextField({
    required String labelText,
    required TextEditingController controller,
    required String hintText,
    TextInputType keyboardType = TextInputType.text,
    String? Function(String?)? validator,
    Function(String)? onChanged,
  }) {
    return Container(
      margin: EdgeInsets.only(bottom: 16.0),
      decoration: BoxDecoration(
        border: Border.all(
          color: Theme.of(context).colorScheme.inversePrimary,
        ),
        borderRadius: BorderRadius.circular(10.0),
      ),
      child: Padding(
        padding: EdgeInsets.all(8.0),
        child: TextFormField(
          controller: controller,
          decoration: InputDecoration(
            labelText: labelText,
            hintText: hintText,
            labelStyle: TextStyle(color: Theme.of(context).colorScheme.inversePrimary),
            hintStyle: TextStyle(color: Theme.of(context).colorScheme.inversePrimary),
          ),
          style: TextStyle(color: Theme.of(context).colorScheme.inversePrimary),
          keyboardType: keyboardType,
          validator: validator,
          onChanged: onChanged,
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final item = Provider.of<Item>(context);

    return Scaffold(
      appBar: AppBar(
        title: Text('Customize Drink'),
      ),
      body: Padding(
        padding: EdgeInsets.all(10.0),
        child: Form(
          key: _formKey,
          child: Container(
            decoration: BoxDecoration(
              border: Border.all(
                color: Theme.of(context).colorScheme.inversePrimary,
              ),
              borderRadius: BorderRadius.circular(10.0),
            ),
            padding: EdgeInsets.all(16.0),
            child: ListView(
              children: [
                Focus(
                  onFocusChange: (hasFocus) {
                    setState(() {
                      _nameFieldHasFocus = hasFocus;
                    });
                  },
                  child: _buildTextField(
                    labelText: 'Drink Name',
                    controller: _nameController,
                    hintText: _nameFieldHasFocus ? '' : 'Enter drink name',
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a drink name';
                      }
                      return null;
                    },
                  ),
                ),
                Focus(
                  onFocusChange: (hasFocus) {
                    setState(() {
                      _descriptionFieldHasFocus = hasFocus;
                    });
                  },
                  child: _buildTextField(
                    labelText: 'Description',
                    controller: _descriptionController,
                    hintText: _descriptionFieldHasFocus ? '' : 'Enter description',
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a description';
                      }
                      return null;
                    },
                  ),
                ),
                Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    Expanded(
                      child: _buildTextField(
                        labelText: 'Image URL',
                        controller: _imageController,
                        hintText: 'Enter image URL or choose from gallery',
                        validator: (value) {
                          if (value == null || value.isEmpty) {
                            return 'Please enter an image URL';
                          }
                          return null;
                        },
                      ),
                    ),
                    SizedBox(width: 8.0),
                    IconButton(
                      icon: Icon(Icons.photo_library),
                      color: Theme.of(context).colorScheme.inversePrimary,
                      onPressed: () => _pickImage(ImageSource.gallery),
                    ),
                  ],
                ),
                SizedBox(height: 16.0),
                Text(
                  'Ingredients (in ml)',
                  style: TextStyle(
                    color: Theme.of(context).colorScheme.inversePrimary,
                    fontSize: 16.0,
                    fontWeight: FontWeight.bold,
                  ),
                ),
                SizedBox(height: 8.0),
                ...List.generate(
                  item.manualDispenserAddons.length,
                      (index) => _buildTextField(
                    labelText: item.manualDispenserAddons[index].name,
                    controller: _addonControllers[index],
                    hintText: 'Volume (in ml)',
                    keyboardType: TextInputType.number,
                    validator: (value) {
                      if (value == null || value.isEmpty) {
                        return 'Please enter a quantity';
                      }
                      final quantity = int.tryParse(value);
                      if (quantity == null || quantity < 0 || quantity > 200) {
                        return 'Quantity must be between 0 and 200 ml';
                      }
                      return null;
                    },
                    onChanged: (value) {
                      setState(() {
                        _addonQuantities[index] = int.tryParse(value) ?? 0;
                      });
                    },
                  ),
                ),
                SizedBox(height: 16.0),
                ElevatedButton(
                  onPressed: _saveDrink,
                  child: Text(
                      'Save',
                       style: TextStyle(color: Colors.green),
                  ),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
