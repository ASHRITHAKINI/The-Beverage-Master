import 'package:flutter/material.dart';
import '../menu/drinks.dart'; // Correct import for the drinkCategory enum

class MyTabBar extends StatelessWidget {
  final TabController tabController;

  const MyTabBar({
    Key? key,
    required this.tabController,
  }) : super(key: key);

  List<Tab> _buildCategoryTabs() {
    return drinkCategory.values.map((category) {
      return Tab(
        child: Text(
          category.toString().split('.').last,
          style: TextStyle(fontSize: 12), // Set a consistent font size
          overflow: TextOverflow.ellipsis, // Handle overflow
        ),
      );
    }).toList();
  }

  @override
  Widget build(BuildContext context) {
    return Container(
      height: 50, // Optional: Limit the height if needed
      child: Row(
        children: [
          Expanded(
            child: TabBar(
              controller: tabController,
              isScrollable: true, // Make the TabBar scrollable
              tabs: _buildCategoryTabs(),
              indicatorSize: TabBarIndicatorSize.label, // Ensure the indicator size matches the label size
              labelPadding: EdgeInsets.symmetric(horizontal: 12.0), // Adjust padding between tabs
              unselectedLabelColor: Theme.of(context).colorScheme.primary, // Set unselected label color
              labelColor: Theme.of(context).colorScheme.inversePrimary, // Set selected label color
            ),
          ),
        ],
      ),
    );
  }
}
