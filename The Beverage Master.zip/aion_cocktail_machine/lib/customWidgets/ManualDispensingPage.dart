import 'dart:io';
import 'package:flutter/material.dart';

class Ingredient {
  final String name;
  final String imagePath;

  Ingredient({required this.name, required this.imagePath});
}

class ManualDispensePage extends StatelessWidget {
  final void Function(String) onDispense;

  final List<Ingredient> ingredients = [
    Ingredient(name: 'Ingredient 1', imagePath: 'lib/images/cocktail/addon1.jpg'),
    Ingredient(name: 'Ingredient 2', imagePath: 'lib/images/cocktail/addon1.jpg'),
  ];

  ManualDispensePage({Key? key, required this.onDispense}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Manual Dispense'),
      ),
      body: ListView.builder(
        itemCount: ingredients.length,
        itemBuilder: (context, index) {
          final ingredient = ingredients[index];
          return Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(8.0),
                child: Column(
                  children: [
                    Image.asset(
                      ingredient.imagePath,
                      width: 100,
                      height: 100,
                      fit: BoxFit.cover,
                    ),
                    SizedBox(height: 8),
                    Text(ingredient.name),
                    SizedBox(height: 8),
                    ElevatedButton(
                      onPressed: () async {
                        // Send command to start dispensing
                        await connectAndDispense('60\n');
                      },
                      child: Text('Dispense'),
                    ),
                    SizedBox(height: 8),
                    ElevatedButton(
                      onPressed: () async {
                        // Send command to stop dispensing
                        await connectAndDispense('61\n');
                      },
                      child: Text('Stop Dispensing'),
                    ),
                  ],
                ),
              ),
              Divider(),
            ],
          );
        },
      ),
    );
  }

  Future<void> connectAndDispense(String command) async {
    try {
      // Connect to WiFi
      await connectToWiFi(command);
    } catch (e) {
      print('Error: $e');
    }
  }

  Future<void> connectToWiFi(String command) async {
    final ipAddress = '192.168.0.1';
    final port = 8080;
    Socket? socket;

    try {
      socket = await Socket.connect(ipAddress, port);
      print('Connected to $ipAddress:$port');

      // Send the command
      socket.write(command);
      print('Command sent: $command');

      // Wait for response if needed
      socket.listen((List<int> data) {
        final response = String.fromCharCodes(data);
        print('Received response: $response');
      });

      await Future.delayed(Duration(seconds: 1)); // Ensure data is sent before closing
    } catch (e) {
      print('Error connecting to $ipAddress:$port: $e');
    } finally {
      socket?.close();
      print('Socket closed');
    }
  }
}
