import 'package:flutter/material.dart';

class DrinkReadyScreen extends StatelessWidget {
  const DrinkReadyScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Drink Ready'),
      ),
      body: Center(
        child: Text(
          'Your drink is ready!',
          style: TextStyle(fontSize: 24),
        ),
      ),
    );
  }
}
