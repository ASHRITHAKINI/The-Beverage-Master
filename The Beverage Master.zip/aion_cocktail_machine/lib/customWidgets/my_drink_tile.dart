import 'dart:async';
import 'dart:io';
import 'package:connectivity/connectivity.dart';
import 'package:flutter/material.dart';
import 'package:flip_card/flip_card.dart';
import '../menu/drinks.dart';
import 'ManualDispenseButton.dart';
import 'SocketManager.dart';
import 'editTile.dart';
import 'package:wifi_iot/wifi_iot.dart' show NetworkSecurity, WiFiForIoTPlugin;

// Helper function to get contrasting text color
Color getContrastingTextColor(Color backgroundColor) {
  double luminance = (0.299 * backgroundColor.red +
      0.587 * backgroundColor.green +
      0.114 * backgroundColor.blue) /
      255;
  return luminance > 0.5 ? Colors.black : Colors.white;
}

class DrinkTile extends StatefulWidget {
  final Drinks drink;
  final void Function()? onTap;
  final bool isManualDispenser;
  final int tileNumber;
  final void Function()? onDelete;

  const DrinkTile({
    Key? key,
    required this.drink,
    this.onTap,
    this.isManualDispenser = false,
    required this.tileNumber,
    this.onDelete,
  }) : super(key: key);

  @override
  _DrinkTileState createState() => _DrinkTileState();
}

class _DrinkTileState extends State<DrinkTile> {
  bool _isDispensing = false;
  final SocketManager _socketManager = SocketManager();

  Future<void> _checkWiFiAndSendCommand(BuildContext context, String command) async {
    var connectivityResult = await (Connectivity().checkConnectivity());
    if (connectivityResult == ConnectivityResult.wifi) {
      await _sendCommand(context, command);
    } else {
      bool connected = await _connectToWiFi(context);
      if (connected) {
        await _sendCommand(context, command);
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Failed to connect to WiFi')),
        );
      }
    }
  }

  Future<bool> _connectToWiFi(BuildContext context) async {
    try {
      bool isConnected = await WiFiForIoTPlugin.connect(
        "Cocktail Machine",
        password: "12345678",
        security: NetworkSecurity.WPA,
        joinOnce: true,
        withInternet: false,
      );
      if (isConnected) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Cocktail Machine connected'),
            duration: Duration(seconds: 2),
          ),
        );
        return true;
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(
            content: Text('Failed to connect to Cocktail Machine'),
            duration: Duration(seconds: 2),
          ),
        );
        return false;
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text('Error connecting to WiFi: $e'),
          duration: Duration(seconds: 2),
        ),
      );
      return false;
    }
  }

  Future<void> _sendCommand(BuildContext context, String command) async {
    try {
      await _socketManager.sendCommand(command);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  void _deleteDrink(BuildContext context) {
    if (widget.onDelete != null) {
      widget.onDelete!();
    }
  }

  Future<void> _showPreparePopup(BuildContext context) async {
    // Show confirmation dialog
    bool shouldPrepare = await showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(
            'Prepare Drink',
            style: TextStyle(color: Theme.of(context).colorScheme.primary),
          ),
          content: Text(
            'Do you want to prepare ${widget.drink.name}?',
            style: TextStyle(color: Theme.of(context).colorScheme.primary),
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(false);
              },
              child: Text('Cancel'),
            ),
            TextButton(
              style: TextButton.styleFrom(
                foregroundColor: Colors.green,
              ),
              onPressed: () {
                Navigator.of(context).pop(true);
              },
              child: Text('Yes'),
            ),
          ],
        );
      },
    );

    if (shouldPrepare) {
      await sendPrepareMessageCustomized(context);
    }
  }

  Future<void> sendPrepareMessageCustomized(BuildContext context) async {
    String command = '50';
    for (var addon in widget.drink.availableAddons) {
      command += ':${addon.quantity}';
    }
    command += '\n';

    await _checkWiFiAndSendCommand(context, command);
    await _checkWiFiAndSendCommand(context, '51\n');

    Completer<void> completer = Completer<void>();

    BuildContext? preparingDialogContext;

    // Show preparing dialog
    showDialog(
      context: context,
      barrierDismissible: false,
      builder: (context) {
        preparingDialogContext = context;
        return AlertDialog(
          title: Text(
            'Preparing Drink',
            style: TextStyle(color: Theme.of(context).colorScheme.primary),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Stack(
                alignment: Alignment.center,
                children: [
                  widget.drink.imagePath.isNotEmpty
                      ? Image.file(
                    File(widget.drink.imagePath),
                    height: 100,
                    fit: BoxFit.cover,
                  )
                      : Image.asset(
                    'lib/images/default.jpg',
                    height: 100,
                    fit: BoxFit.cover,
                  ),
                  CircularProgressIndicator(),
                ],
              ),
              SizedBox(height: 20),
              Text(
                'Your drink is being prepared...',
                style: TextStyle(color: Theme.of(context).colorScheme.primary),
              ),
            ],
          ),
        );
      },
    );

    // Listen for signals and handle them
    _socketManager.listenForSignals((message) {
      print('Received signal: $message'); // Print the message

      if (!completer.isCompleted) {
        if (message == '53') {
          // Complete the completer if signal '53' is received
          completer.complete();
        } else if (message == '52') {
          // Handle signal '52' if needed
          // Optionally, you can log or process it here
        }
        // Ignore other signals and empty messages
      }
    });

    // Wait for the completer to complete
    try {
      await completer.future;
      // Dismiss preparing dialog
      if (preparingDialogContext != null) {
        Navigator.of(preparingDialogContext!).pop(); // Close preparing popup
        preparingDialogContext = null;
      }
      // Show drink ready popup
      _showDrinkReadyPopup(context);
    } catch (e) {
      print('Error while waiting for signal: $e');
      // Handle any potential errors here
      if (preparingDialogContext != null) {
        Navigator.of(preparingDialogContext!).pop(); // Close preparing popup
        preparingDialogContext = null;
      }
      // Optionally, you can show an error message or retry mechanism
    }
  }

  Future<void> _showDrinkReadyPopup(BuildContext context) async {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(
            'Drink Ready',
            style: TextStyle(color: Theme.of(context).colorScheme.primary),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Your drink is ready!',
                style: TextStyle(color: Theme.of(context).colorScheme.primary),
              ),
              SizedBox(height: 20),
              widget.drink.imagePath.isNotEmpty
                  ? Image.file(
                File(widget.drink.imagePath),
                height: 100,
                fit: BoxFit.cover,
              )
                  : Image.asset(
                'lib/images/default.jpg',
                height: 100,
                fit: BoxFit.cover,
              ),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop(); // Close ready popup
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }

  @override
  Widget build(BuildContext context) {
    final screenWidth = MediaQuery.of(context).size.width;
    final tileWidth = screenWidth * 0.93;
    final bool displayButtons = !widget.isManualDispenser &&
        (widget.drink.category == drinkCategory.Cocktail ||
            widget.drink.category == drinkCategory.Mocktail);
    final backgroundColor = Theme.of(context).colorScheme.background;
    final textColor = getContrastingTextColor(backgroundColor);

    return Center(
      child: Padding(
        padding: const EdgeInsets.all(8.0),
        child: SingleChildScrollView(
          scrollDirection: Axis.horizontal,
          child: SizedBox(
            width: tileWidth,
            child: GestureDetector(
              onTap: widget.onTap,
              child: ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: FlipCard(
                  direction: FlipDirection.HORIZONTAL,
                  front: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      color: backgroundColor,
                      border: Border.all(color: Colors.white, width: 1), // Add white border
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black26,
                          blurRadius: 10,
                          offset: Offset(0, 4),
                        ),
                      ],
                    ),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(10.0),
                          child: Row(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Expanded(
                                child: Column(
                                  crossAxisAlignment: CrossAxisAlignment.start,
                                  children: [
                                    Text(
                                      '${widget.drink.name}',
                                      style: TextStyle(
                                        fontSize: 18,
                                        fontWeight: FontWeight.bold,
                                        color: textColor,
                                      ),
                                    ),
                                    const SizedBox(height: 8),
                                    if (displayButtons)
                                      Row(
                                        children: [
                                          ElevatedButton(
                                            style: ElevatedButton.styleFrom(
                                              backgroundColor: Theme.of(context).colorScheme.secondary, // Set button color
                                              shape: RoundedRectangleBorder(
                                                borderRadius: BorderRadius.circular(10),
                                              ),
                                              padding: EdgeInsets.symmetric(horizontal: 24, vertical: 12),
                                              side: BorderSide(color: Colors.white, width: 1), // Add white border
                                            ),
                                            onPressed: () async {
                                              await _showPreparePopup(context);
                                            },
                                            child: Text(
                                              "Prepare",
                                              style: const TextStyle(fontSize: 12),
                                            ),
                                          ),
                                        ],
                                      ),
                                    if (widget.isManualDispenser)
                                      ManualDispenseButton(
                                        tileNumber: widget.tileNumber,
                                        isDispensing: _isDispensing,
                                        onDispenseStatusChanged: (isDispensing) {
                                          setState(() {
                                            _isDispensing = isDispensing;
                                          });
                                        },
                                        imagePath: widget.drink.imagePath,
                                      ),
                                  ],
                                ),
                              ),
                              const SizedBox(width: 8),
                              Container(
                                width: 100,
                                height: 100,
                                child: ClipRRect(
                                  borderRadius: BorderRadius.circular(8),
                                  child: widget.drink.imagePath.isNotEmpty
                                      ? Image.file(
                                    File(widget.drink.imagePath),
                                    fit: BoxFit.cover,
                                    errorBuilder: (context, error, stackTrace) {
                                      return const Icon(Icons.error);
                                    },
                                  )
                                      : Image.asset(
                                    'lib/images/default.jpg',
                                    fit: BoxFit.cover,
                                    errorBuilder: (context, error, stackTrace) {
                                      return const Icon(Icons.error);
                                    },
                                  ),
                                ),
                              ),
                            ],
                          ),
                        ),
                      ],
                    ),
                  ),
                  back: Container(
                    decoration: BoxDecoration(
                      borderRadius: BorderRadius.circular(16),
                      color: backgroundColor,
                      border: Border.all(color: Colors.white, width: 1), // Add white border
                      boxShadow: [
                        BoxShadow(
                          color: Colors.black26,
                          blurRadius: 10,
                          offset: Offset(0, 4),
                        ),
                      ],
                    ),
                    alignment: Alignment.center,
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Padding(
                          padding: const EdgeInsets.all(16.0),
                          child: Text(
                            widget.drink.description,
                            style: TextStyle(
                              fontSize: 16,
                              color: textColor,
                            ),
                            textAlign: TextAlign.center,
                          ),
                        ),
                        Row(
                          mainAxisAlignment: MainAxisAlignment.center,
                          children: [
                            IconButton(
                              onPressed: () {
                                Navigator.push(
                                  context,
                                  MaterialPageRoute(
                                    builder: (context) => EditTilePage(drink: widget.drink),
                                  ),
                                );
                              },
                              icon: Icon(
                                Icons.edit,
                                color: Theme.of(context).colorScheme.inversePrimary,
                              ),
                            ),
                            if (!widget.isManualDispenser) // Only show delete button if not a manual dispenser
                              IconButton(
                                onPressed: () {
                                  _deleteDrink(context);
                                },
                                icon: Icon(
                                  Icons.delete,
                                  color: Theme.of(context).colorScheme.inversePrimary,
                                ),
                              ),
                          ],
                        ),
                      ],
                    ),
                  ),
                ),
              ),
            ),
          ),
        ),
      ),
    );
  }
}
