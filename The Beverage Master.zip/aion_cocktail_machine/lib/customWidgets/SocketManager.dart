import 'dart:async';
import 'dart:io';

class SocketManager {
  static final SocketManager _instance = SocketManager._internal();
  Socket? _socket;
  final String _ipAddress = '192.168.0.1';
  final int _port = 8080;
  final StreamController<String> _responseController = StreamController<String>.broadcast(); // Broadcast stream for responses

  SocketManager._internal();

  factory SocketManager() {
    return _instance;
  }

  Stream<String> get responses => _responseController.stream;
  late StreamController<String> _messageController;
  late StreamController<dynamic> _errorController;
  late StreamController<void> _disconnectController;

  Future<void> connect() async {
    if (_socket != null) return; // Already connected

    try {
      _socket = await Socket.connect(_ipAddress, _port);
      _messageController = StreamController<String>.broadcast(); // Broadcast stream for messages
      _errorController = StreamController<dynamic>.broadcast(); // Broadcast stream for errors
      _disconnectController = StreamController<void>.broadcast(); // Broadcast stream for disconnections
      _socket!.listen((List<int> data) {
        final response = String.fromCharCodes(data);
        _responseController.add(response);
        _messageController.add(response); // Notify listeners of new messages
      }, onError: (error) {
        print('Socket error: $error');
        _responseController.addError(error);
        _errorController.add(error); // Notify listeners of errors
        _socket = null; // Invalidate the socket on error
      }, onDone: () {
        print('Socket closed by server');
        _socket = null;
        _disconnectController.add(null); // Notify listeners of disconnection
      });
    } catch (e) {
      print('Error connecting to socket: $e');
      _socket = null;
    }
  }

  Future<void> sendCommand(String command) async {
    await connect();
    if (_socket != null) {
      _socket!.write(command);
    } else {
      throw Exception('Socket is not connected');
    }
  }

  Future<bool> listenForReadySignal() async {
    try {
      // Listen for the ready signal '53'
      if (_socket != null) {
        final response = await _socket!.firstWhere((data) {
          final responseString = String.fromCharCodes(data);
          return responseString.trim() == '53'; // Adjust based on actual data format
        });

        final responseString = String.fromCharCodes(response);
        return responseString.trim() == '53';
      }
      return false;
    } catch (e) {
      print('Error listening for ready signal: $e');
      return false;
    }
  }

  // Method to send a dispense command
  Future<void> sendDispenseCommand(String command) async {
    await sendCommand(command); // Reuse sendCommand to send the actual command
  }

  // Method to send a prepare command
  Future<void> sendPrepareCommand(String command) async {
    await sendCommand(command); // Reuse sendCommand to send the actual command
  }

  Future<void> listenForSignals(void Function(String) onSignalReceived) async {
    try {
      // Listen for any signals and call the callback with the received message
      _messageController.stream.listen((message) {
        onSignalReceived(message.trim());
      });
    } catch (e) {
      print('Error listening for signals: $e');
    }
  }

  void dispose() {
    _socket?.destroy();
    _responseController.close();
    _messageController.close();
    _errorController.close();
    _disconnectController.close();
  }

  void subscribeToMessages(void Function(String) onData) {
    _messageController.stream.listen(onData);
  }

  void subscribeToError(void Function(dynamic) onError) {
    _errorController.stream.listen(onError);
  }

  void subscribeToDisconnect(void Function() onDisconnect) {
    _disconnectController.stream.listen((_) {
      _disconnectController.close(); // Close the disconnect controller
      onDisconnect();
    });
  }
}
