import 'package:flutter/material.dart';
import '../menu/drinks.dart'; // Import the drinkCategory enum

class MySliverAppBar extends StatelessWidget {
  final TabController tabController;
  final Widget title;
  final Widget child;

  const MySliverAppBar({
    Key? key,
    required this.tabController,
    required this.title,
    required this.child,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return SliverAppBar(
      expandedHeight: 60, // Reduced the expanded height
      collapsedHeight: 60, // Ensures it doesn't expand/collapse
      floating: false,
      pinned: true,
      centerTitle: false, // Set to false to align title to the left
      actions: [
        Padding(
          padding: const EdgeInsets.only(left: 50.0, right: 40.0), // Increased left padding
          child: Text(
            'THE BAR CRAFTER', // Your heading text
            style: TextStyle(
              color: Theme.of(context).colorScheme.inversePrimary,
              fontSize: 18,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        IconButton(
          onPressed: () {
            // Your onPressed logic here
          },
          icon: Image.asset(
            'lib/images/logo/logo.png',
            width: 35,
            height: 35,
          ),
        ),
      ],
      backgroundColor: Theme.of(context).colorScheme.background,
      foregroundColor: Theme.of(context).colorScheme.inversePrimary,
      title: title,
      bottom: PreferredSize(
        preferredSize: Size.fromHeight(50), // Adjust the height to accommodate the TabBar
        child: TabBar(
          controller: tabController,
          labelColor: Theme.of(context).colorScheme.inversePrimary, // Set the selected label color
          unselectedLabelColor: Theme.of(context).colorScheme.inversePrimary.withOpacity(0.6), // Set the unselected label color
          tabs: drinkCategory.values.map((category) {
            return Tab(text: category.toString().split('.').last);
          }).toList(),
        ),
      ),
    );
  }
}
