import 'dart:async';

import 'package:flutter/material.dart';
import 'SocketManager.dart';

class DrinkPreparationManager {
  final SocketManager _socketManager;
  BuildContext? preparingDialogContext;
  bool _isPreparingDialogOpen = false;
  bool _hasShownDrinkReadyPopup = false;
  bool _waitingFor52 = false;
  StreamSubscription? _signalSubscription;

  DrinkPreparationManager(this._socketManager);

  Future<void> sendPrepareMessageCustomized(BuildContext context, String command) async {
    // Clean up any existing listeners
    _signalSubscription?.cancel();
    _signalSubscription = null;

    await sendCommand(context, command);
    await sendCommand(context, '51\n');

    // Show preparing dialog
    if (!_isPreparingDialogOpen) {
      _isPreparingDialogOpen = true;
      showDialog(
        context: context,
        barrierDismissible: false,
        builder: (context) {
          preparingDialogContext = context;
          return AlertDialog(
            title: Text(
              'Preparing Drink',
              style: TextStyle(color: Theme.of(context).colorScheme.primary),
            ),
            content: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Stack(
                  alignment: Alignment.center,
                  children: [
                    Image.asset(
                      'lib/images/default.jpg',
                      height: 100,
                      fit: BoxFit.cover,
                    ),
                    CircularProgressIndicator(),
                  ],
                ),
                SizedBox(height: 20),
                Text(
                  'Your drink is being prepared...',
                  style: TextStyle(color: Theme.of(context).colorScheme.primary),
                ),
              ],
            ),
          );
        },
      ).then((_) {
        _isPreparingDialogOpen = false;
        _hasShownDrinkReadyPopup = false;
      });
    }

    await waitForSignals(context);
  }

  Future<void> sendCommand(BuildContext context, String command) async {
    try {
      await _socketManager.sendCommand(command);
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  Future<void> waitForSignals(BuildContext context) async {
    bool received52 = false;
    bool received53 = false;

    _signalSubscription = _socketManager.listenForSignals((message) {
      print('Received signal: $message'); // Print the message

      if (!_waitingFor52 && message == '52') {
        received52 = true;
        _waitingFor52 = true;
      } else if (_waitingFor52 && message == '53') {
        received53 = true;
      } else {
        return;
      }

      if (received52 && received53) {
        if (_isPreparingDialogOpen) {
          Navigator.of(preparingDialogContext!).pop(); // Close preparing popup
          _isPreparingDialogOpen = false;
          _waitingFor52 = false;

          if (!_hasShownDrinkReadyPopup) {
            _hasShownDrinkReadyPopup = true;
            Future.delayed(Duration(seconds: 1), () {
              _showDrinkReadyPopup(context);
            });
          }
        }
      }
    }) as StreamSubscription?;
  }

  Future<void> _showDrinkReadyPopup(BuildContext context) async {
    showDialog(
      context: context,
      builder: (context) {
        return AlertDialog(
          title: Text(
            'Drink Ready',
            style: TextStyle(color: Theme.of(context).colorScheme.primary),
          ),
          content: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Text(
                'Your drink is ready!',
                style: TextStyle(color: Theme.of(context).colorScheme.primary),
              ),
              SizedBox(height: 20),
            ],
          ),
          actions: [
            TextButton(
              onPressed: () {
                Navigator.of(context).pop();
              },
              child: Text('OK'),
            ),
          ],
        );
      },
    );
  }
}
