import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../customWidgets/customizeDrinkPage.dart';
import '../customWidgets/my_description_box.dart';
import '../customWidgets/my_drawer.dart';
import '../customWidgets/my_drink_tile.dart';
import '../customWidgets/my_silver_app_bar.dart';
import '../menu/drinks.dart';
import '../menu/item.dart';
import '../themes/themeProvider.dart';
import 'package:wifi_iot/wifi_iot.dart' show WiFiForIoTPlugin;
import 'drink_page.dart';

class HomePage extends StatefulWidget {
  const HomePage({Key? key}) : super(key: key);

  @override
  State<HomePage> createState() => _HomePageState();
}

class _HomePageState extends State<HomePage> with SingleTickerProviderStateMixin {
  late TabController _tabController;
  int _highestMocktailTileNumber = 0;
  int _highestCocktailTileNumber = 0;
  int _highestManualDispenserTileNumber = 0;
  bool _isConnectedToWiFi = false;
  Color buttonColor = Color.fromARGB(255, 30, 30, 30);

  @override
  void initState() {
    super.initState();
    _tabController = TabController(
      length: drinkCategory.values.length,
      vsync: this,
      initialIndex: drinkCategory.ManualDispenser.index,
    );
    _loadHighestTileNumbers();
    _initializeHighestTileNumbers();
    _checkWiFiStatus();
  }

  @override
  void dispose() {
    _tabController.dispose();
    super.dispose();
  }

  Future<void> _loadHighestTileNumbers() async {
    final prefs = await SharedPreferences.getInstance();
    setState(() {
      _highestMocktailTileNumber = prefs.getInt('highestMocktailTileNumber') ?? 0;
      _highestCocktailTileNumber = prefs.getInt('highestCocktailTileNumber') ?? 0;
      _highestManualDispenserTileNumber = prefs.getInt('highestManualDispenserTileNumber') ?? 0;
    });
  }

  Future<void> _saveHighestTileNumbers() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.setInt('highestMocktailTileNumber', _highestMocktailTileNumber);
    await prefs.setInt('highestCocktailTileNumber', _highestCocktailTileNumber);
    await prefs.setInt('highestManualDispenserTileNumber', _highestManualDispenserTileNumber);
  }

  void _initializeHighestTileNumbers() {
    final drinks = Provider.of<Item>(context, listen: false).drinks;
    for (var drink in drinks) {
      if (drink.category == drinkCategory.Mocktail && drink.tileNumber != null) {
        _highestMocktailTileNumber = _highestMocktailTileNumber > drink.tileNumber! ? _highestMocktailTileNumber : drink.tileNumber!;
      } else if (drink.category == drinkCategory.Cocktail && drink.tileNumber != null) {
        _highestCocktailTileNumber = _highestCocktailTileNumber > drink.tileNumber! ? _highestCocktailTileNumber : drink.tileNumber!;
      } else if (drink.category == drinkCategory.ManualDispenser && drink.tileNumber != null) {
        _highestManualDispenserTileNumber = _highestManualDispenserTileNumber > drink.tileNumber! ? _highestManualDispenserTileNumber : drink.tileNumber!;
      }
    }
  }

  void _addDrink(Drinks drink) {
    Provider.of<Item>(context, listen: false).addDrink(drink);
    setState(() {
      if (drink.category == drinkCategory.Mocktail) {
        _highestMocktailTileNumber = drink.tileNumber!;
      } else if (drink.category == drinkCategory.Cocktail) {
        _highestCocktailTileNumber = drink.tileNumber!;
      } else if (drink.category == drinkCategory.ManualDispenser) {
        _highestManualDispenserTileNumber = drink.tileNumber!;
      }
      _saveHighestTileNumbers();
    });
  }

  void _deleteDrink(Drinks drink) {
    Provider.of<Item>(context, listen: false).removeDrink(drink);
    setState(() {
      if (drink.category == drinkCategory.Mocktail && drink.tileNumber == _highestMocktailTileNumber) {
        _highestMocktailTileNumber = _getHighestTileNumber(drinkCategory.Mocktail);
      } else if (drink.category == drinkCategory.Cocktail && drink.tileNumber == _highestCocktailTileNumber) {
        _highestCocktailTileNumber = _getHighestTileNumber(drinkCategory.Cocktail);
      } else if (drink.category == drinkCategory.ManualDispenser && drink.tileNumber == _highestManualDispenserTileNumber) {
        _highestManualDispenserTileNumber = _getHighestTileNumber(drinkCategory.ManualDispenser);
      }
      _saveHighestTileNumbers();
    });
  }

  int _getHighestTileNumber(drinkCategory category) {
    final drinks = Provider.of<Item>(context, listen: false).drinks;
    int highestNumber = 0;
    for (var drink in drinks) {
      if (drink.category == category && drink.tileNumber != null) {
        highestNumber = highestNumber > drink.tileNumber! ? highestNumber : drink.tileNumber!;
      }
    }
    return highestNumber;
  }

  List<Drinks> _filterMenuByCategory(drinkCategory category, List<Drinks> fullMenu) {
    List<Drinks> filteredMenu = fullMenu.where((drink) => drink.category == category).toList();
    filteredMenu.sort((a, b) => (a.tileNumber ?? 0).compareTo(b.tileNumber ?? 0));
    return filteredMenu;
  }

  void _checkWiFiStatus() async {
    bool isConnected = await WiFiForIoTPlugin.isConnected();
    setState(() {
      _isConnectedToWiFi = isConnected;
    });
  }

  @override
  Widget build(BuildContext context) {
    final themeProvider = Provider.of<ThemeProvider>(context);
    final drinks = Provider.of<Item>(context).drinks;

    return Scaffold(
      drawer: MyDrawer(onReset: () {}),
      backgroundColor: Theme.of(context).colorScheme.secondary,
      body: SafeArea(
        child: CustomScrollView(
          slivers: [
            MySliverAppBar(
              title: Text('THE BAR CRAFTER'),
              tabController: _tabController,
              child: SizedBox.shrink(),
            ),
            SliverToBoxAdapter(
              child: MyDescriptionBox(description: _isConnectedToWiFi ? 'Connected to WiFi' : ''),
            ),
            SliverFillRemaining(
              child: TabBarView(
                controller: _tabController,
                children: drinkCategory.values.map((category) {
                  List<Drinks> categoryMenu = _filterMenuByCategory(category, drinks);
                  if (category == drinkCategory.ManualDispenser) {
                    int manualDispenserTileCount = categoryMenu.length < 6 ? 6 : categoryMenu.length;

                    return ListView.builder(
                      itemCount: manualDispenserTileCount,
                      physics: const AlwaysScrollableScrollPhysics(),
                      padding: EdgeInsets.zero,
                      itemBuilder: (context, index) {
                        if (index < categoryMenu.length) {
                          final drink = categoryMenu[index];
                          return DrinkTile(
                            drink: drink,
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => DrinkPage(drink: drink),
                              ),
                            ),
                            tileNumber: drink.tileNumber ?? 0,
                            isManualDispenser: true,
                          );
                        } else {
                          int defaultTileNumber = index + 1; // Ensure starting from 1
                          String drinkName = Provider.of<Item>(context, listen: false).manualDispenserNames[(defaultTileNumber - 1) % 6];
                          return DrinkTile(
                            drink: Drinks(
                              name: drinkName,
                              description: 'Description for $drinkName',
                              imagePath: 'lib/images/manualDispenser/addon',
                              category: drinkCategory.ManualDispenser,
                              availableAddons: [],
                              tileNumber: defaultTileNumber,
                            ),
                            onTap: () {
                              Drinks newDrink = Drinks(
                                name: ' ',
                                description: ' ',
                                imagePath: 'assets/default_image.png',
                                category: drinkCategory.ManualDispenser,
                                availableAddons: [],
                                tileNumber: defaultTileNumber,
                              );

                              Navigator.push(
                                context,
                                MaterialPageRoute(
                                  builder: (context) => CustomizeDrinkPage(
                                    drink: newDrink,
                                    onDrinkSaved: (drink) {
                                      _addDrink(drink);
                                    },
                                  ),
                                ),
                              );
                            },
                            tileNumber: defaultTileNumber,
                            onDelete: null,
                            isManualDispenser: true,
                          );
                        }
                      },
                    );
                  } else {
                    return ListView.builder(
                      itemCount: categoryMenu.length + 1,
                      physics: const AlwaysScrollableScrollPhysics(),
                      padding: EdgeInsets.zero,
                      itemBuilder: (context, index) {
                        if (index < categoryMenu.length) {
                          final drink = categoryMenu[index];
                          return DrinkTile(
                            drink: drink,
                            onTap: () => Navigator.push(
                              context,
                              MaterialPageRoute(
                                builder: (context) => DrinkPage(drink: drink),
                              ),
                            ),
                            tileNumber: drink.tileNumber ?? 0,
                            onDelete: () => _deleteDrink(drink),
                          );
                        } else {
                          return Center(
                            child: SizedBox(
                              width: 200, // Set desired width
                              child: // Inside your build method
                              InkWell(
                                onTap: () {
                                  setState(() {
                                    buttonColor = Colors.grey.withOpacity(0.5); // Change to lighter shade
                                  });
                                  Future.delayed(Duration(milliseconds: 50), () {
                                    setState(() {
                                      buttonColor = Theme.of(context).colorScheme.background; // Revert color
                                    });
                                    int newTileNumber;
                                    if (category == drinkCategory.Mocktail) {
                                      newTileNumber = _highestMocktailTileNumber + 1;
                                    } else if (category == drinkCategory.Cocktail) {
                                      newTileNumber = _highestCocktailTileNumber + 1;
                                    } else {
                                      newTileNumber = _highestManualDispenserTileNumber + 1;
                                    }

                                    Drinks newDrink = Drinks(
                                      name: 'New Drink',
                                      description: 'New Drink Description',
                                      imagePath: 'assets/default_image.png',
                                      category: category,
                                      availableAddons: [],
                                      tileNumber: newTileNumber,
                                    );

                                    Navigator.push(
                                      context,
                                      MaterialPageRoute(
                                        builder: (context) => CustomizeDrinkPage(
                                          drink: newDrink,
                                          onDrinkSaved: (drink) {
                                            _addDrink(drink);
                                          },
                                        ),
                                      ),
                                    );
                                  });
                                },
                                borderRadius: BorderRadius.circular(10),
                                child: Ink(
                                  decoration: BoxDecoration(
                                    color: buttonColor, // Use variable color
                                    borderRadius: BorderRadius.circular(10),
                                    border: Border.all(
                                      color: Theme.of(context).colorScheme.primary,
                                      width: 2,
                                    ),
                                  ),
                                  padding: EdgeInsets.symmetric(horizontal: 30, vertical: 12),
                                  child: Center(
                                    child: Text(
                                      'Add Drink Tile',
                                      style: TextStyle(color: Colors.white),
                                    ),
                                  ),
                                ),
                              ),
                            ),
                          );
                        }
                      },
                    );
                  }
                }).toList(),
              ),
            ),
          ],
        ),
      ),
    );
  }
}
