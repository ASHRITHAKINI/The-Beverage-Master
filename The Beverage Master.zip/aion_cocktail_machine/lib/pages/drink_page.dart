import 'package:flutter/material.dart';
import '../menu/drinks.dart';

class DrinkPage extends StatefulWidget {
  final Drinks drink;

  const DrinkPage({
    Key? key,
    required this.drink,
  }) : super(key: key);

  @override
  State<DrinkPage> createState() => _DrinkPageState();
}

class _DrinkPageState extends State<DrinkPage> {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(widget.drink.name),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        crossAxisAlignment: CrossAxisAlignment.center,
        children: [
          Expanded(
            child: Center(
              child: Container( // Wrap the Image.asset with a Container
                width: MediaQuery.of(context).size.width, // Set width to screen width
                child: Image.asset(
                  widget.drink.imagePath,
                  errorBuilder: (context, error, stackTrace) {
                    return Icon(Icons.error); // Display an error icon if the image fails to load
                  },
                ),
              ),
            ),
          ),
          Column(
            children: [
              Padding(
                padding: const EdgeInsets.all(16.0),
                child: Text(
                  widget.drink.description,
                  style: TextStyle(fontSize: 18, color: Theme.of(context).colorScheme.inversePrimary), // Set text color to inversePrimary
                  textAlign: TextAlign.center,
                ),
              ),
              const SizedBox(height: 16),
              ListView.builder(
                shrinkWrap: true,
                physics: const NeverScrollableScrollPhysics(),
                itemCount: widget.drink.availableAddons.length,
                itemBuilder: (context, index) {
                  Addon addon = widget.drink.availableAddons[index];
                  return CheckboxListTile(
                    title: Text(
                      addon.name,
                      style: TextStyle(color: Theme.of(context).colorScheme.inversePrimary),
                    ),
                    subtitle: Text(
                      '₹ ${addon.maxVolume.toStringAsFixed(2)}',
                      style: TextStyle(color: Theme.of(context).colorScheme.inversePrimary),
                    ),
                    value: false,
                    activeColor: Theme.of(context).colorScheme.inversePrimary, // Set checkbox color to inversePrimary
                    onChanged: (value) {
                      // Add your checkbox logic here
                    },
                  );
                },
              ),
            ],
          ),
        ],
      ),
    );
  }
}
