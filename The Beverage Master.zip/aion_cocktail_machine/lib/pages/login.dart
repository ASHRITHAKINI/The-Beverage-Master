// import 'package:cocktail_machine/customWidgets/my_button.dart';
// import 'package:cocktail_machine/customWidgets/my_textfield.dart';
// import 'package:cocktail_machine/pages/homepage.dart';
// import 'package:flutter/material.dart';
//
// class LoginPage extends StatefulWidget{
//
//   final void Function()? onTap;
//
//   const LoginPage({
//     super.key,
//     required this.onTap,
//   });
//
//   @override
//   State<LoginPage> createState() => _LoginPageState();
// }
//
// class _LoginPageState extends State<LoginPage> {
//   final TextEditingController emailController = TextEditingController();
//   final TextEditingController passwordController = TextEditingController();
//
//   void login(){
//     Navigator.push(
//       context,
//       MaterialPageRoute(
//         builder: (context) => const HomePage(),
//       ),
//     );
//   }
//
//   @override
//   Widget build(BuildContext context) {
//     return Scaffold(
//       body: Stack(
//         children: [
//           // Background image
//           Container(
//             decoration: const BoxDecoration(
//               image: DecorationImage(
//                 image: NetworkImage(
//                     'https://images.pexels.com/photos/2093089/pexels-photo-2093089.jpeg?auto=compress&cs=tinysrgb&w=1260&h=750&dpr=1'
//                 ),
//                 fit: BoxFit.cover,
//               ),
//             ),
//           ),
//           // Page content
//           Padding(
//             padding: const EdgeInsets.all(32),
//             child: Column(
//               mainAxisAlignment: MainAxisAlignment.center,
//               children: [
//                 Expanded(
//                   child: Column(
//                     mainAxisAlignment: MainAxisAlignment.center,
//                     children: [
//                       const SizedBox(height: 25),
//
//                       const Text(
//                         "Cocktail Machine App",
//                         style: TextStyle(
//                           fontSize: 25,
//                           color: Colors.white,
//                           fontWeight: FontWeight.bold,
//                         ),
//                       ),
//
//                       const SizedBox(height: 330),
//
//                       const TextField(
//                         textAlign: TextAlign.center,
//                         decoration: InputDecoration(
//                           hintText: 'Login',
//                           hintStyle: TextStyle(
//                             color: Colors.white,
//                             fontSize: 24,
//                             fontWeight: FontWeight.bold,
//                           ),
//                         ),
//                       ),
//
//                       const SizedBox(height: 15),
//
//                       MyTextfield(
//                         controller: emailController,
//                         hintText: "Enter email",
//                         obscureText: false,
//                       ),
//
//                       const SizedBox(height: 15),
//
//                       MyTextfield(
//                         controller: passwordController,
//                         hintText: "Enter password",
//                         obscureText: true,
//                       ),
//
//                     ],
//                   ),
//                 ),
//                 Column(
//                   children: [
//                     MyButton(
//                       text: "Sign In",
//                       onTap: login,
//                     ),
//                     const SizedBox(height: 25),
//                     Row(
//                       mainAxisAlignment: MainAxisAlignment.center,
//                       children: [
//                         Text(
//                           "Not a member?",
//                           style: TextStyle(
//                             color: Theme.of(context).colorScheme.inversePrimary,
//                           ),
//                         ),
//                         const SizedBox(width: 4),
//                         GestureDetector(
//                           onTap: widget.onTap,
//                           child: Text(
//                             "Sign Up Here!!!",
//                             style: TextStyle(
//                               color: Theme.of(context).colorScheme.inversePrimary,
//                               fontWeight: FontWeight.bold,
//                             ),
//                           ),
//                         ),
//                       ],
//                     ),
//                   ],
//                 ),
//               ],
//             ),
//           ),
//         ],
//       ),
//     );
//   }
// }
