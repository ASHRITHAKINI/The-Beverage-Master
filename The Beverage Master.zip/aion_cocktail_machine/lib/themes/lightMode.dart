import 'package:flutter/material.dart';

ThemeData lightMode = ThemeData(
    colorScheme: ColorScheme.light(
        background: Colors.purple.shade800,
        primary: Colors.white,
        secondary: const Color.fromARGB(255, 40, 40, 40),
        tertiary: Colors.white,
        inversePrimary: Colors.white,
    )
);
