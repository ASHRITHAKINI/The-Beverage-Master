import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import 'drinks.dart';

class Item extends ChangeNotifier {
  List<Drinks> _drinks = [];
  List<Drinks> get drinks => _drinks;

  List<String> _manualDispenserNames = [
    "Manual Dispenser 1",
    "Manual Dispenser 2",
    "Manual Dispenser 3",
    "Manual Dispenser 4",
    "Manual Dispenser 5",
    "Manual Dispenser 6"
  ];
  List<String> get manualDispenserNames => _manualDispenserNames;

  List<Addon> manualDispenserAddons = [];

  final List<Addon> mocktailAddons = [
    Addon(name: "Mint Leaves", maxVolume: 200),
    Addon(name: "Lemon Twist", maxVolume: 200),
    Addon(name: "Ice Cubes", maxVolume: 200),
  ];

  final List<Addon> cocktailAddons = [
    Addon(name: "Ice Cubes", maxVolume: 200),
    Addon(name: "Lemon Wedge", maxVolume: 200),
    Addon(name: "Olives", maxVolume: 200),
  ];

  final List<Drinks> manualDispensingDrinks = [
    Drinks(
      name: 'Manual Drink 1',
      description: 'Description for manual drink 1',
      imagePath: 'lib/images/manualDispenser/drink1.png',
      category: drinkCategory.ManualDispenser,
      availableAddons: [],
      tileNumber: 1,
    ),
    Drinks(
      name: 'Manual Drink 2',
      description: 'Description for manual drink 2',
      imagePath: 'lib/images/manualDispenser/drink2.png',
      category: drinkCategory.ManualDispenser,
      availableAddons: [],
      tileNumber: 2,
    ),
    Drinks(
      name: 'Manual Drink 3',
      description: 'Description for manual drink 3',
      imagePath: 'lib/images/manualDispenser/drink3.png',
      category: drinkCategory.ManualDispenser,
      availableAddons: [],
      tileNumber: 3,
    ),
    Drinks(
      name: 'Manual Drink 4',
      description: 'Description for manual drink 4',
      imagePath: 'lib/images/manualDispenser/drink4.png',
      category: drinkCategory.ManualDispenser,
      availableAddons: [],
      tileNumber: 4,
    ),
    Drinks(
      name: 'Manual Drink 5',
      description: 'Description for manual drink 5',
      imagePath: 'lib/images/manualDispenser/drink5.png',
      category: drinkCategory.ManualDispenser,
      availableAddons: [],
      tileNumber: 5,
    ),
    Drinks(
      name: 'Manual Drink 6',
      description: 'Description for manual drink 6',
      imagePath: 'lib/images/manualDispenser/drink6.png',
      category: drinkCategory.ManualDispenser,
      availableAddons: [],
      tileNumber: 6,
    ),
  ];

  Item() {
    _loadDrinksFromPrefs();
    _loadManualDispenserNamesFromPrefs();
    _initializeManualDispenserAddons();
  }

  void _initializeManualDispenserAddons() {
    manualDispenserAddons = _manualDispenserNames.map((name) => Addon(name: name, maxVolume: 200)).toList();
  }

  List<Addon> getAvailableAddons(String category) {
    switch (category) {
      case 'Cocktail':
        return cocktailAddons;
      case 'Mocktail':
        return mocktailAddons;
      case 'ManualDispenser':
        return manualDispenserAddons;
      default:
        return [];
    }
  }

  void addDrink(Drinks drink) {
    _drinks.add(drink);
    _saveDrinksToPrefs();
    notifyListeners();
  }

  void removeDrink(Drinks drink) {
    _drinks.remove(drink);
    _saveDrinksToPrefs();
    notifyListeners();
  }

  void updateDrink(Drinks updatedDrink) {
    int index = _drinks.indexWhere((drink) => drink.tileNumber == updatedDrink.tileNumber);
    if (index != -1) {
      _drinks[index] = updatedDrink;
      _saveDrinksToPrefs();
      notifyListeners();

      if (updatedDrink.category == drinkCategory.ManualDispenser) {
        updateManualDispenserName(updatedDrink.tileNumber! - 1, updatedDrink.name);
      }
    }
  }

  void updateManualDispenserName(int index, String newName) {
    if (index >= 0 && index < _manualDispenserNames.length) {
      _manualDispenserNames[index] = newName;
      _initializeManualDispenserAddons(); // Reinitialize addons with updated names
      _saveManualDispenserNamesToPrefs();
      notifyListeners();
    }
  }

  void resetCocktailAndMocktailDrinks() {
    _drinks.removeWhere((drink) =>
    drink.category == 'Cocktail' || drink.category == 'Mocktail');
    _saveDrinksToPrefs();
    notifyListeners();
  }

  void _loadDrinksFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final drinksJson = prefs.getString('drinks');
    if (drinksJson != null) {
      _drinks = (json.decode(drinksJson) as List).map((e) => Drinks.fromJson(e)).toList();
      notifyListeners();
    } else {
      _drinks.addAll(manualDispensingDrinks);
      _saveDrinksToPrefs();
    }
  }

  void _loadManualDispenserNamesFromPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    final namesJson = prefs.getString('manualDispenserNames');
    if (namesJson != null) {
      _manualDispenserNames = List<String>.from(json.decode(namesJson));
      _initializeManualDispenserAddons();
      notifyListeners();
    }
  }

  void _saveManualDispenserNamesToPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString('manualDispenserNames', json.encode(_manualDispenserNames));
  }

  void _saveDrinksToPrefs() async {
    final prefs = await SharedPreferences.getInstance();
    prefs.setString('drinks', json.encode(_drinks.map((e) => e.toJson()).toList()));
  }
}
