enum drinkCategory { Mocktail, Cocktail, ManualDispenser }

class Addon {
  final String name;
  final int maxVolume;
  int quantity;

  Addon({required this.name, required this.maxVolume, this.quantity = 0});

  Map<String, dynamic> toJson() => {
    'name': name,
    'maxVolume': maxVolume,
    'quantity': quantity,
  };

  factory Addon.fromJson(Map<String, dynamic> json) => Addon(
    name: json['name'],
    maxVolume: json['maxVolume'],
    quantity: json['quantity'] ?? 0,
  );
}


class Drinks {
  final String name;
  final String description;
  final String imagePath;
  final drinkCategory category;
  final List<Addon> availableAddons;
  final int? tileNumber;

  Drinks({
    required this.name,
    required this.description,
    required this.imagePath,
    required this.category,
    required this.availableAddons,
    this.tileNumber,
  });

  Drinks copyWith({
    String? name,
    String? description,
    String? imagePath,
    drinkCategory? category,
    List<Addon>? availableAddons,
    int? tileNumber,
  }) {
    return Drinks(
      name: name ?? this.name,
      description: description ?? this.description,
      imagePath: imagePath ?? this.imagePath,
      category: category ?? this.category,
      availableAddons: availableAddons ?? this.availableAddons,
      tileNumber: tileNumber ?? this.tileNumber,
    );
  }

  Map<String, dynamic> toJson() => {
    'name': name,
    'description': description,
    'imagePath': imagePath,
    'category': category.toString(),
    'availableAddons': availableAddons.map((e) => e.toJson()).toList(),
    'tileNumber': tileNumber,
  };

  factory Drinks.fromJson(Map<String, dynamic> json) => Drinks(
    name: json['name'],
    description: json['description'],
    imagePath: json['imagePath'],
    category: drinkCategory.values.firstWhere(
            (e) => e.toString() == json['category']),
    availableAddons: (json['availableAddons'] as List)
        .map((e) => Addon.fromJson(e))
        .toList(),
    tileNumber: json['tileNumber'],
  );
}

